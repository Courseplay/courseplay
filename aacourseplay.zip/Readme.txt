Schritt 1: aacourseplay.zip ins Mod-Verzeichnis kopieren. Die "aa" am Anfang des Namens sind wichtig, damit dieser Mod vor allen anderen geladen wird

Schritt 2: Folgendes in die modDesc.xml des gewünschten Schleppers eintragen:
  
<vehicleTypes>
	...
	...
	...		
	<specialization name="courseplay" />		
</vehicleTypes>


Anleitung:

- Am Startpunkt Taste "K" drücken.
- gewünschte Strecke abfahren
- Um Wartepunkte zu setzen NUMPAD 0 drücken (der Schlepper hält beim abfahren hier an)
- Am Zielpunkt nochmal "K" drücken um die Aufzeichnung zu beenden
- Wenn ihr nicht mehr als 15 (Spiel)Meter vom Startpunkt entfernt seid könnt ihr mit der Taste "J" den Abfahrer starten.
- Seid ihr weiter als 15 Meter erscheint ein Pfeil der euch zum Startpunkt lotst.

- Routen speichern könnt ihr mit STRG+S, den Namen der Route mit Enter bestätigen.
- Routen laden geht mit STRG+O, den Cursortasten zur Auswahl und Enter zum bestätigen.